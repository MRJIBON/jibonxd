# apt update && apt upgrade 

# apt install git

# apt install python 

# apt install python2 

# pip2 install requests mechanize

# git clone https://github.com/Ajijul123a/Jibon75.git

# cd Jibon75

# ls

# python2 Jibon75.py

# USER: Jibon
# PASS: Ponir.Turjo
